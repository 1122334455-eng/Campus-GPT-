# CampusGPT
Creating CampusGPT for our University
